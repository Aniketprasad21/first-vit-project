import React from 'react'
import style from "./navbar.module.css"
const Navbar = () => {
  return (
    <nav>
      <aside className={style.logo}>logo</aside>
      <ul className={style.menu}>
        <li><a href='/'>home</a></li>
        <li><a href='/about'>about</a></li>
        <li><a href='/register'>register</a></li>
        <li><a href='/login'>login</a></li>
        <li><a href='/profile'>profile</a></li>
      </ul>
    </nav>
  )
}

export default Navbar
