import React from 'react'
import style from "./home.module.css"
const Home = () => {
  return (
    <div>
      home
    </div>
  )
}

export default Home
